@echo off
title Ipak Yo'li - Telefonga o'rnatish
cd /d "%~dp0"
set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not exist "%ADB%" ( echo [XATO] adb topilmadi. Android SDK platform-tools kerak. & pause & exit /b 1 )
set "APK=app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK%" ( echo [XATO] APK topilmadi. Avval build-apk.bat ni ishga tushiring. & pause & exit /b 1 )
echo Qurilma ulanmoqda... (telefonda USB debugging yoqilgan bo'lsin)
"%ADB%" install -r "%APK%"
pause
