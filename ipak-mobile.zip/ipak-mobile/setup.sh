#!/bin/bash
# =============================================================================
# Ipak Yo'li Android - birinchi marta sozlash
# Gradle wrapper, local.properties va gradlew huquqini tayyorlaydi.
# =============================================================================
set -e
echo ""
echo "=========================================="
echo "  Ipak Yo'li Android - Setup"
echo "=========================================="
echo ""

if ! command -v java &> /dev/null; then
    echo "❌ Java topilmadi! JDK 17+ o'rnating: https://adoptium.net/"
    exit 1
fi
JAVA_VERSION=$(java -version 2>&1 | head -1 | awk -F'"' '{print $2}' | awk -F'.' '{print $1}')
if [ "$JAVA_VERSION" -lt "17" ]; then
    echo "❌ Java $JAVA_VERSION topildi, 17+ kerak. https://adoptium.net/"
    exit 1
fi
echo "✅ Java $JAVA_VERSION OK"

if [ -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    echo "✅ Gradle wrapper mavjud"
else
    echo "⚠️  gradle-wrapper.jar yo'q — Android Studio'da loyihani oching (avtomatik yuklaydi)"
    echo "    yoki 'gradle wrapper --gradle-version 8.9' ni ishga tushiring."
    if command -v gradle &> /dev/null; then
        gradle wrapper --gradle-version 8.9 --distribution-type bin
        echo "✅ Gradle wrapper yaratildi"
    fi
fi

if [ ! -f "local.properties" ]; then
    if [ -n "$ANDROID_HOME" ]; then SDK_PATH="$ANDROID_HOME"
    elif [ -n "$ANDROID_SDK_ROOT" ]; then SDK_PATH="$ANDROID_SDK_ROOT"
    elif [ -d "$HOME/Android/Sdk" ]; then SDK_PATH="$HOME/Android/Sdk"
    elif [ -d "$HOME/Library/Android/sdk" ]; then SDK_PATH="$HOME/Library/Android/sdk"
    else SDK_PATH=""; fi
    if [ -n "$SDK_PATH" ]; then
        echo "sdk.dir=$SDK_PATH" > local.properties
        echo "✅ local.properties yaratildi: $SDK_PATH"
    else
        echo "⚠️  Android SDK topilmadi. local.properties.example'ni ko'chiring va sdk.dir ni to'g'rilang."
    fi
fi

[ -x "gradlew" ] || chmod +x gradlew
echo ""
echo "=========================================="
echo "  Setup tugadi! Build:"
echo "    ./gradlew assembleDebug     # debug APK"
echo "    ./gradlew installDebug      # qurilmaga o'rnatish"
echo "  APK: app/build/outputs/apk/debug/app-debug.apk"
echo "=========================================="
