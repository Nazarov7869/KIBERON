@echo off
setlocal enabledelayedexpansion
title Ipak Yo'li - APK Builder
echo.
echo ==============================================================
echo          Ipak Yo'li Android APK Builder
echo ==============================================================
echo.
cd /d "%~dp0"

if not exist "app\build.gradle.kts" ( echo [XATO] Loyiha topilmadi! & pause & exit /b 1 )

echo [1/4] JDK tekshirilmoqda...
java -version >nul 2>&1
if errorlevel 1 ( echo [XATO] Java JDK yo'q. Avval setup.bat ni ishga tushiring. & pause & exit /b 1 )
echo [OK] JDK topildi

echo [2/4] Android SDK tekshirilmoqda...
set "ANDROID_SDK_PATH="
if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools" set "ANDROID_SDK_PATH=%ANDROID_HOME%"
if not defined ANDROID_SDK_PATH if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools" set "ANDROID_SDK_PATH=%LOCALAPPDATA%\Android\Sdk"
if not defined ANDROID_SDK_PATH ( echo [XATO] Android SDK topilmadi. Android Studio o'rnating. & pause & exit /b 1 )
echo [OK] Android SDK: %ANDROID_SDK_PATH%

echo [3/4] local.properties...
if not exist "local.properties" (
    >"local.properties" echo sdk.dir=%ANDROID_SDK_PATH:\=/%
)
echo [OK] local.properties tayyor

echo [4/4] APK build qilinmoqda... (birinchi marta Gradle yuklanadi, 5-15 daqiqa)
echo.
call gradlew.bat assembleDebug
if errorlevel 1 ( echo. & echo [XATO] Build muvaffaqiyatsiz. Internet/antivirus/disk joyini tekshiring. & pause & exit /b 1 )

set "APK_PATH=app\build\outputs\apk\debug\app-debug.apk"
echo.
if exist "%APK_PATH%" (
    echo ==============================================================
    echo                   MUVAFFAQIYAT!
    echo   APK: %CD%\%APK_PATH%
    echo ==============================================================
    explorer "app\build\outputs\apk\debug"
) else (
    echo [XATO] APK topilmadi!
)
echo.
pause >nul
endlocal
