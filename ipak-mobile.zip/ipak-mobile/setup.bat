@echo off
title Ipak Yo'li - Setup
echo.
echo ==========================================
echo   Ipak Yo'li Android - Setup
echo ==========================================
echo.
cd /d "%~dp0"

java -version >nul 2>&1
if errorlevel 1 ( echo [XATO] Java JDK topilmadi. JDK 17+ o'rnating: https://adoptium.net/ & pause & exit /b 1 )
echo [OK] Java topildi

if exist "gradle\wrapper\gradle-wrapper.jar" (
    echo [OK] Gradle wrapper mavjud
) else (
    echo [OGOH] gradle-wrapper.jar yo'q - Android Studio'da loyihani ochsangiz avtomatik yuklanadi.
)

if not exist "local.properties" (
    if defined ANDROID_HOME (
        >"local.properties" echo sdk.dir=%ANDROID_HOME:\=/%
        echo [OK] local.properties yaratildi: %ANDROID_HOME%
    ) else if exist "%LOCALAPPDATA%\Android\Sdk" (
        >"local.properties" echo sdk.dir=%LOCALAPPDATA:\=/%/Android/Sdk
        echo [OK] local.properties yaratildi
    ) else (
        echo [OGOH] Android SDK topilmadi. local.properties.example'ni ko'chiring.
    )
)
echo.
echo Setup tugadi. Build uchun: build-apk.bat
echo.
pause
