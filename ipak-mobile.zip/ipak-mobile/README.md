# Ipak Yo'li — mobil ilova (Android, Kotlin + Compose)

Milliy agroeksport CRM'ning mobil mijozi. Backend (`ipak-yoli/backend`, FastAPI)
bilan JWT orqali ishlaydi. Texnologiya: **Kotlin 2.0 · Jetpack Compose · Hilt ·
Navigation · DataStore · OkHttp** (KIBERON bilan bir xil build uslubi).

> Holat: **M2 — to'liq funksional** — kirish (login), boshqaruv (dashboard),
> narx kalkulyatori, **Karta (sputnik)**, **Birja (bozor tahlili)**,
> **AI maslahatchi (chat)** va **Hujjat tahlili** tayyor.

## Imkoniyatlar (pastki navigatsiya)
- **Asosiy** — rol bo'yicha yo'riqnoma, platforma katalogi statistikasi, narx kalkulyatori.
- **Karta** — bepul **sputnik karta** (Leaflet WebView + Esri, Leaflet ilova ichida
  joylashtirilgan, faqat plitalar internet talab qiladi). Avval o'z manzilingizni
  belgilaysiz (kartani bosib), so'ng ombor/logistika/bozor/hamkorlar ko'rinadi.
  **Yo'nalish taklifi**: mahsulot + manzil bozorini tanlab — eng yaqin omborlar,
  koridor, logistika firmalari (kodlari bilan) va marshrut chizig'i chiziladi.
- **Birja** — har mahsulot bo'yicha oxirgi narx, o'zgarish %, 30-kunlik yuqori/past,
  hajm va **shamli (candlestick) grafik** (Compose Canvas).
- **AI** — eksport bo'yicha AI maslahatchi (chat). Backend `/api/ai/advisor`.
- **Hujjat** — PDF/DOCX/TXT shartnoma/invoysni yuklab yoki matn joylashtirib,
  AI mutaxassis tahlili (shartlar, xavflar, tavsiyalar). Backend `/api/ai/analyze-file`.

Barcha ekranlar `ApiClient` orqali backend bilan ishlaydi (JWT avtomatik).

## Talablar
- **JDK 17+** (Android Studio bilan keladi) — https://adoptium.net
- **Android Studio** (Ladybug yoki yangiroq) + Android SDK (API 35)
- Ishlab turgan **Ipak Yo'li backend** (test uchun)

## Build qilish (KIBERON kabi)

**Eng oson — Android Studio:**
1. Android Studio → *Open* → `ipak-mobile` papkasini tanlang
2. Gradle sync tugashini kuting (birinchi marta bog'liqliklar yuklanadi)
3. *Run* ▶ (emulator yoki ulangan telefon)

**Buyruq qatori (Windows):** `build-apk.bat` — JDK/SDK tekshiradi, Gradle yuklaydi, APK yasaydi.

**Buyruq qatori (Linux/macOS):**
```bash
chmod +x setup.sh gradlew
./setup.sh                    # local.properties + wrapper
./gradlew assembleDebug       # debug APK
```
APK joyi: `app/build/outputs/apk/debug/app-debug.apk`

Telefonga o'rnatish: `install-to-phone.bat` (Windows) yoki `./gradlew installDebug`.

## Backend manzilini sozlash
`app/build.gradle.kts` ichida `API_BASE_URL`:
- **debug** (emulator): `http://10.0.2.2:4000` — emulatordagi `10.0.2.2` = kompyuteringiz `localhost`i. Backendni `./start.sh` bilan ishga tushiring.
- **release**: `https://api.ipakyoli.uz` — o'z domeningizga o'zgartiring.

Haqiqiy telefonda (emulator emas) test qilsangiz, debug `API_BASE_URL` ni
kompyuteringiz LAN IP'siga o'zgartiring (masalan `http://192.168.1.50:4000`) va
telefon bilan bir Wi-Fi'da bo'ling.

## Kirish
Backend seed super-admin: **admin@ipakyoli.uz / admin12345**
(yoki o'zingiz ro'yxatdan o'tgan eksportyor/importyor).

## Loyiha tuzilishi
```
ipak-mobile/
├─ app/src/main/java/uz/ipakyoli/app/
│  ├─ IpakApp.kt · MainActivity.kt          # Application (Hilt) + Activity
│  ├─ core/network/                          # ApiClient (OkHttp), ApiModels
│  ├─ data/                                  # TokenStore (DataStore), AuthRepository
│  ├─ di/AppModule.kt                        # Hilt providerlar
│  ├─ ui/theme/                              # Koshin majolika (och tema)
│  ├─ ui/components/                         # umumiy komponentlar
│  ├─ ui/auth/                               # Login
│  ├─ ui/home/                               # Boshqaruv (dashboard)
│  └─ ui/nav/                                # Auth darvozasi
├─ build-apk.bat · setup.sh · setup.bat      # build skriptlari
└─ gradle/libs.versions.toml                 # versiyalar katalogi
```

## Build stack (KIBERON bilan bir xil)
Gradle 8.9 · AGP 8.7.0 · Kotlin 2.0.20 · Compose BOM 2024.10 · Hilt 2.52 ·
minSdk 26 · targetSdk/compileSdk 35 · Java 17.
