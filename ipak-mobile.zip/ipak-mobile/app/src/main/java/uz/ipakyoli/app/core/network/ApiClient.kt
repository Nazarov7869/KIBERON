package uz.ipakyoli.app.core.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URLEncoder
import uz.ipakyoli.app.BuildConfig
import uz.ipakyoli.app.data.TokenStore
import javax.inject.Inject
import javax.inject.Singleton

// =====================================================================
//  API mijoz — OkHttp + kotlinx.serialization. JWT token avtomatik qo'shiladi.
//  Backend manzili: BuildConfig.API_BASE_URL (debug=10.0.2.2:4000, release=prod).
// =====================================================================
@Singleton
class ApiClient @Inject constructor(
    private val http: OkHttpClient,
    private val json: Json,
    private val tokenStore: TokenStore,
) {
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val emptyBody: RequestBody = ByteArray(0).toRequestBody(null, 0, 0)

    private suspend fun request(method: String, path: String, bodyJson: String?): String =
        withContext(Dispatchers.IO) {
            val builder = Request.Builder().url(BuildConfig.API_BASE_URL + path)
            tokenStore.tokenFlow.first()?.let { token ->
                if (token.isNotEmpty()) builder.header("Authorization", "Bearer $token")
            }
            val reqBody = bodyJson?.toRequestBody(jsonMedia)
            when (method) {
                "GET" -> builder.get()
                "POST" -> builder.post(reqBody ?: emptyBody)
                "PUT" -> builder.put(reqBody ?: emptyBody)
                "PATCH" -> builder.patch(reqBody ?: emptyBody)
                "DELETE" -> if (reqBody != null) builder.delete(reqBody) else builder.delete()
                else -> builder.get()
            }
            http.newCall(builder.build()).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw ApiException(resp.code, extractError(text) ?: "Xatolik (${resp.code})")
                }
                text
            }
        }

    /** Backend xato javobidan xabarni ajratib olish ({error} yoki {detail}). */
    private fun extractError(text: String): String? = try {
        val obj = json.parseToJsonElement(text).jsonObject
        (obj["error"] ?: obj["detail"])?.jsonPrimitive?.content
    } catch (_: Exception) {
        null
    }

    // ---- Endpointlar (M1) ----------------------------------------------
    suspend fun login(email: String, password: String): TokenResponse {
        val body = json.encodeToString(LoginRequest.serializer(), LoginRequest(email, password))
        val text = request("POST", "/api/auth/login", body)
        return json.decodeFromString(TokenResponse.serializer(), text)
    }

    suspend fun me(): User {
        // Backend UserOut'ni TO'G'RIDAN qaytaradi ({id,role,name,email,company_id}), o'ralmagan
        val text = request("GET", "/api/auth/me", null)
        return json.decodeFromString(User.serializer(), text)
    }

    suspend fun catalogSummary(): Summary {
        val text = request("GET", "/api/catalog/summary", null)
        return json.decodeFromString(SummaryResponse.serializer(), text).summary
    }

    // ---- Katalog -------------------------------------------------------
    suspend fun products(): List<Product> {
        val text = request("GET", "/api/catalog/products", null)
        return json.decodeFromString(ProductsResponse.serializer(), text).products
    }

    // ---- Birja (bozor tahlili) ----------------------------------------
    suspend fun marketSummary(): MarketSummary {
        val text = request("GET", "/api/market/summary", null)
        return json.decodeFromString(MarketSummary.serializer(), text)
    }

    suspend fun marketCandles(productId: String, limit: Int = 120, source: String? = null): CandlesResponse {
        var path = "/api/market/candles?product_id=${enc(productId)}&limit=$limit"
        if (!source.isNullOrBlank()) path += "&source=${enc(source)}"
        val text = request("GET", path, null)
        return json.decodeFromString(CandlesResponse.serializer(), text)
    }

    // ---- Karta ---------------------------------------------------------
    suspend fun mapMe(): MyLoc {
        val text = request("GET", "/api/map/me", null)
        return json.decodeFromString(MyLoc.serializer(), text)
    }

    suspend fun mapSetMe(lat: Double, lng: Double, address: String? = null): MyLoc {
        val body = json.encodeToString(LocationBody.serializer(), LocationBody(lat, lng, address))
        val text = request("PUT", "/api/map/me", body)
        return json.decodeFromString(MyLoc.serializer(), text)
    }

    suspend fun mapFeatures(): MapFeatures {
        val text = request("GET", "/api/map/features", null)
        return json.decodeFromString(MapFeatures.serializer(), text)
    }

    suspend fun mapSuggestions(marketId: String, productId: String? = null): Suggestions {
        var path = "/api/map/suggestions?market_id=${enc(marketId)}"
        if (!productId.isNullOrBlank()) path += "&product_id=${enc(productId)}"
        val text = request("GET", path, null)
        return json.decodeFromString(Suggestions.serializer(), text)
    }

    // ---- AI ------------------------------------------------------------
    suspend fun aiStatus(): AiStatus {
        val text = request("GET", "/api/ai/status", null)
        return json.decodeFromString(AiStatus.serializer(), text)
    }

    suspend fun aiAdvisor(question: String): AdvisorResponse {
        val body = json.encodeToString(AdvisorBody.serializer(), AdvisorBody(question))
        val text = request("POST", "/api/ai/advisor", body)
        return json.decodeFromString(AdvisorResponse.serializer(), text)
    }

    suspend fun aiAnalyzeText(text: String, kind: String? = null): AnalyzeResponse {
        val body = json.encodeToString(AnalyzeBody.serializer(), AnalyzeBody(text, kind))
        val resp = request("POST", "/api/ai/analyze", body)
        return json.decodeFromString(AnalyzeResponse.serializer(), resp)
    }

    /** PDF/DOCX/TXT faylni yuklab, matnini ajratib AI tahlil qiladi (multipart). */
    suspend fun aiAnalyzeFile(bytes: ByteArray, filename: String, kind: String? = null): AnalyzeResponse =
        withContext(Dispatchers.IO) {
            val part = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart(
                    "file", filename,
                    bytes.toRequestBody("application/octet-stream".toMediaType(), 0, bytes.size),
                )
            if (!kind.isNullOrBlank()) part.addFormDataPart("kind", kind)
            val builder = Request.Builder()
                .url(BuildConfig.API_BASE_URL + "/api/ai/analyze-file")
                .post(part.build())
            tokenStore.tokenFlow.first()?.let { token ->
                if (token.isNotEmpty()) builder.header("Authorization", "Bearer $token")
            }
            http.newCall(builder.build()).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw ApiException(resp.code, extractError(body) ?: "Xatolik (${resp.code})")
                }
                json.decodeFromString(AnalyzeResponse.serializer(), body)
            }
        }

    private fun enc(v: String): String = URLEncoder.encode(v, "UTF-8")
}
