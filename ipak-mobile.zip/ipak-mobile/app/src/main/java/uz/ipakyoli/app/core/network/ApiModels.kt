package uz.ipakyoli.app.core.network

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// =====================================================================
//  Backend javob shakllariga mos data klasslar (kotlinx.serialization)
// =====================================================================

@Serializable
data class User(
    val id: String,
    val role: String,
    val name: String,
    val email: String,
    @SerialName("company_id") val companyId: String? = null,
)

@Serializable
data class TokenResponse(
    val ok: Boolean = true,
    @SerialName("access_token") val accessToken: String,
    @SerialName("token_type") val tokenType: String = "bearer",
    val user: User,
)

@Serializable
data class MeResponse(val ok: Boolean = true, val user: User)

@Serializable
data class Summary(
    val products: Int = 0,
    val markets: Int = 0,
    val corridors: Int = 0,
    val warehouses: Int = 0,
    val providers: Int = 0,
    val certifications: Int = 0,
    @SerialName("price_refs") val priceRefs: Int = 0,
)

@Serializable
data class SummaryResponse(val ok: Boolean = true, val summary: Summary)

@Serializable
data class LoginRequest(val email: String, val password: String)

/** Rol -> o'zbekcha nom (UI uchun). */
object Roles {
    val labels = mapOf(
        "super_admin" to "Operator",
        "exporter" to "Eksportyor",
        "importer" to "Importyor",
        "logistics" to "Logistika",
        "warehouse" to "Ombor",
        "embassy" to "Elchixona",
    )

    fun label(role: String): String = labels[role] ?: role

    fun hint(role: String): String = when (role) {
        "super_admin" -> "Korxonalarni tasdiqlang, xodim qo'shing, poollarni kuzating."
        "exporter" -> "Lot joylang, konteynerlarga qo'shiling, ulushingizni oling."
        "importer" -> "Talab (RFQ) bering, konteyner ochib to'ldiring, escrow orqali xarid qiling."
        "logistics" -> "Tasdiqlangan buyurtmalarni jo'nating va yetkazib bering."
        "warehouse" -> "Lotlar sifatini tekshiring — sifat pooling balliga ta'sir qiladi."
        "embassy" -> "Tashqi bozordagi xaridorlar va talabni kiriting."
        else -> "Ipak Yo'li eksport platformasi."
    }
}
