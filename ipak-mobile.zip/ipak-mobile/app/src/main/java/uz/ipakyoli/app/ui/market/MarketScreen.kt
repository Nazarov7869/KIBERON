package uz.ipakyoli.app.ui.market

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.core.network.Candle
import uz.ipakyoli.app.core.network.Ticker
import uz.ipakyoli.app.ui.components.ErrorBox
import uz.ipakyoli.app.ui.components.LoadingBox
import uz.ipakyoli.app.ui.components.SectionCard
import uz.ipakyoli.app.ui.theme.Bad
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.Faint
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Line
import uz.ipakyoli.app.ui.theme.Muted
import uz.ipakyoli.app.ui.theme.Ok
import uz.ipakyoli.app.ui.theme.Surface

private val UP = Color(0xFF1E9E61)
private val DOWN = Color(0xFFD14B3C)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketScreen(vm: MarketViewModel = hiltViewModel()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bozor tahlili", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
            )
        },
        containerColor = Bg,
    ) { pad ->
        Column(modifier = Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
            when {
                vm.loading -> LoadingBox()
                vm.error != null && vm.items.isEmpty() -> ErrorBox(vm.error!!)
                else -> {
                    Spacer(Modifier.height(6.dp))
                    vm.selected?.let { SelectedHeader(it, vm.candles, vm.loadingCandles) }
                    Spacer(Modifier.height(12.dp))
                    Text("BARCHA MAHSULOTLAR", fontSize = 11.sp, color = Faint, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(vm.items) { t ->
                            TickerRow(t, selected = t.productId == vm.selected?.productId) { vm.select(t) }
                        }
                        item { Spacer(Modifier.height(20.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectedHeader(t: Ticker, candles: List<Candle>, loading: Boolean) {
    SectionCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
        ) {
            Column {
                Text(t.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("USD / tonna", fontSize = 12.sp, color = Muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(fmtUsd(t.last), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                ChangeBadge(t.changePct)
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(modifier = Modifier.fillMaxWidth().height(160.dp)) {
            when {
                loading -> LoadingBox()
                candles.isEmpty() -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center,
                ) { Text("Ma'lumot yo‘q", fontSize = 13.sp, color = Faint) }
                else -> CandleChart(candles, Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            MiniStat("30k yuqori", fmtUsd(t.high30d))
            MiniStat("30k past", fmtUsd(t.low30d))
            MiniStat("Hajm", t.volume?.let { fmtNum(it) + " t" } ?: "—")
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column {
        Text(label, fontSize = 11.sp, color = Faint)
        Text(value, fontSize = 13.sp, color = Ink, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChangeBadge(pct: Double?) {
    val up = (pct ?: 0.0) >= 0
    val c = if (up) Ok else Bad
    val txt = pct?.let { (if (up) "+" else "") + fmtNum(it) + "%" } ?: "—"
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(c.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    ) {
        Text(txt, color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TickerRow(t: Ticker, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Feruza.copy(alpha = 0.08f) else Surface)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(t.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            t.kind?.let { Text(it, fontSize = 11.sp, color = Faint) }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(fmtUsd(t.last), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            val up = (t.changePct ?: 0.0) >= 0
            Text(
                t.changePct?.let { (if (up) "▲ " else "▼ ") + fmtNum(kotlin.math.abs(it)) + "%" } ?: "—",
                fontSize = 12.sp,
                color = if (up) Ok else Bad,
            )
        }
    }
}

@Composable
private fun CandleChart(candles: List<Candle>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (candles.isEmpty()) return@Canvas
        val w = size.width
        val h = size.height
        val hi = candles.maxOf { it.h }
        val lo = candles.minOf { it.l }
        val range = (hi - lo).coerceAtLeast(1e-6)
        fun y(v: Double): Float = ((hi - v) / range).toFloat() * h
        val n = candles.size
        val slot = w / n
        val bodyW = (slot * 0.62f).coerceIn(1.2f, 12f)
        candles.forEachIndexed { i, c ->
            val cx = slot * i + slot / 2f
            val up = c.c >= c.o
            val col = if (up) UP else DOWN
            // soya (wick)
            drawLine(
                color = col,
                start = Offset(cx, y(c.h)),
                end = Offset(cx, y(c.l)),
                strokeWidth = 1.4f,
            )
            // tana (body)
            val top = y(kotlin.math.max(c.o, c.c))
            val bot = y(kotlin.math.min(c.o, c.c))
            drawRect(
                color = col,
                topLeft = Offset(cx - bodyW / 2f, top),
                size = Size(bodyW, (bot - top).coerceAtLeast(1.5f)),
            )
        }
    }
}

private fun fmtUsd(v: Double?): String =
    if (v == null) "—" else "$" + String.format("%,.0f", v)

private fun fmtNum(v: Double): String =
    if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.1f", v)
