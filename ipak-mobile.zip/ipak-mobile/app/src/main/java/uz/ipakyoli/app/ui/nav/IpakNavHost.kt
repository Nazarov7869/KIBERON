package uz.ipakyoli.app.ui.nav

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.ui.ai.AiChatScreen
import uz.ipakyoli.app.ui.auth.LoginScreen
import uz.ipakyoli.app.ui.calc.CalcScreen
import uz.ipakyoli.app.ui.docs.DocScreen
import uz.ipakyoli.app.ui.home.HomeScreen
import uz.ipakyoli.app.ui.map.MapScreen
import uz.ipakyoli.app.ui.market.MarketScreen
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Feruza050
import uz.ipakyoli.app.ui.theme.Faint
import uz.ipakyoli.app.ui.theme.Surface

private data class Tab(val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("Asosiy", Icons.Filled.Home),
    Tab("Karta", Icons.Filled.Place),
    Tab("Birja", Icons.Filled.ShowChart),
    Tab("AI", Icons.Filled.AutoAwesome),
    Tab("Hujjat", Icons.Filled.Description),
)

@Composable
fun IpakNavHost(gateVm: AuthGateViewModel = hiltViewModel()) {
    val state by gateVm.state.collectAsState()

    when (state) {
        is AuthUi.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Feruza)
        }

        is AuthUi.LoggedOut -> {
            // Ochiq oqim: login <-> kalkulyator (login shart emas)
            var route by rememberSaveable { mutableStateOf("login") }
            when (route) {
                "calc" -> CalcScreen(onBack = { route = "login" })
                else -> LoginScreen(onOpenCalc = { route = "calc" })
            }
        }

        is AuthUi.LoggedIn -> MainShell()
    }
}

@Composable
private fun MainShell() {
    var tab by rememberSaveable { mutableStateOf(0) }
    var showCalc by rememberSaveable { mutableStateOf(false) }

    if (showCalc) {
        CalcScreen(onBack = { showCalc = false })
        return
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surface, tonalElevation = 0.dp) {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Feruza,
                            selectedTextColor = Feruza,
                            indicatorColor = Feruza050,
                            unselectedIconColor = Faint,
                            unselectedTextColor = Faint,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(modifier = Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding())) {
            when (tab) {
                0 -> HomeScreen(onOpenCalc = { showCalc = true })
                1 -> MapScreen()
                2 -> MarketScreen()
                3 -> AiChatScreen()
                else -> DocScreen()
            }
        }
    }
}
