package uz.ipakyoli.app.ui.docs

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.ipakyoli.app.core.network.AnalyzeResponse
import uz.ipakyoli.app.core.network.ApiClient
import javax.inject.Inject

@HiltViewModel
class DocViewModel @Inject constructor(
    private val api: ApiClient,
    @ApplicationContext private val context: Context,
) : ViewModel() {

    var pastedText by mutableStateOf(""); private set
    var analyzing by mutableStateOf(false); private set
    var result by mutableStateOf<AnalyzeResponse?>(null); private set
    var error by mutableStateOf<String?>(null); private set
    var pickedName by mutableStateOf<String?>(null); private set

    fun onText(v: String) { pastedText = v }

    fun reset() {
        result = null; error = null; pickedName = null; pastedText = ""
    }

    fun analyzeText() {
        val t = pastedText.trim()
        if (t.length < 20) { error = "Kamida 20 ta belgi matn kiriting"; return }
        pickedName = null
        viewModelScope.launch {
            analyzing = true; error = null; result = null
            runCatching { api.aiAnalyzeText(t) }
                .onSuccess { result = it }
                .onFailure { error = it.message }
            analyzing = false
        }
    }

    fun analyzeUri(uri: Uri) {
        viewModelScope.launch {
            analyzing = true; error = null; result = null
            val name = queryName(uri)
            val bytes = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                }.getOrNull()
            }
            pickedName = name
            if (bytes == null || bytes.isEmpty()) {
                error = "Faylni o‘qib bo‘lmadi"; analyzing = false; return@launch
            }
            if (bytes.size > 10 * 1024 * 1024) {
                error = "Fayl juda katta (maksimum 10 MB)"; analyzing = false; return@launch
            }
            runCatching { api.aiAnalyzeFile(bytes, name) }
                .onSuccess { result = it }
                .onFailure { error = it.message }
            analyzing = false
        }
    }

    private fun queryName(uri: Uri): String {
        var name = "hujjat"
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) c.getString(idx)?.let { name = it }
                    }
                }
        }
        return name
    }
}
