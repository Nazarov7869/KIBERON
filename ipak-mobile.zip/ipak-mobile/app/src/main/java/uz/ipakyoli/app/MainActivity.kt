package uz.ipakyoli.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import dagger.hilt.android.AndroidEntryPoint
import uz.ipakyoli.app.ui.nav.IpakNavHost
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.IpakTheme

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IpakTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    IpakNavHost()
                }
            }
        }
    }
}
