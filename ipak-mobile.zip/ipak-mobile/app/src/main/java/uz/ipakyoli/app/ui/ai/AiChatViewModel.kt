package uz.ipakyoli.app.ui.ai

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import uz.ipakyoli.app.core.network.AiStatus
import uz.ipakyoli.app.core.network.ApiClient
import javax.inject.Inject

data class ChatMsg(val fromUser: Boolean, val text: String)

@HiltViewModel
class AiChatViewModel @Inject constructor(
    private val api: ApiClient,
) : ViewModel() {

    var messages by mutableStateOf<List<ChatMsg>>(emptyList()); private set
    var input by mutableStateOf(""); private set
    var sending by mutableStateOf(false); private set
    var status by mutableStateOf<AiStatus?>(null); private set

    val suggestions = listOf(
        "Anorni Rossiyaga eksport qilishning eng foydali yo‘li qanday?",
        "FOB va CIF o‘rtasidagi farq nima?",
        "Quritilgan mevani BAAga sotish uchun qanday sertifikat kerak?",
        "Valyuta tushumini repatriatsiya muddati qancha?",
    )

    init { loadStatus() }

    fun loadStatus() {
        viewModelScope.launch { runCatching { api.aiStatus() }.onSuccess { status = it } }
    }

    fun onInput(v: String) { input = v }

    fun sendText(text: String) {
        val q = text.trim()
        if (q.length < 3 || sending) return
        messages = messages + ChatMsg(true, q)
        input = ""
        sending = true
        viewModelScope.launch {
            runCatching { api.aiAdvisor(q) }
                .onSuccess { messages = messages + ChatMsg(false, it.answer?.ifBlank { "—" } ?: "—") }
                .onFailure {
                    messages = messages + ChatMsg(
                        false,
                        "⚠️ " + (it.message ?: "Javob olinmadi. AI provayder sozlanmagan bo‘lishi mumkin."),
                    )
                }
            sending = false
        }
    }

    fun send() = sendText(input)
}
