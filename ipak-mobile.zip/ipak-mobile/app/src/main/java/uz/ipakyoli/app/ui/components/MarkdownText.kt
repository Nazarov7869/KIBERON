package uz.ipakyoli.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Muted

/** **bold** qismlarni ajratib AnnotatedString qaytaradi. */
private fun inlineBold(text: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        val start = text.indexOf("**", i)
        if (start < 0) { append(text.substring(i)); break }
        append(text.substring(i, start))
        val end = text.indexOf("**", start + 2)
        if (end < 0) { append(text.substring(start)); break }
        pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
        append(text.substring(start + 2, end))
        pop()
        i = end + 2
    }
}

/**
 * Yengil markdown ko'rsatkich — AI javoblari uchun (## sarlavha, **qalin**, - ro'yxat).
 * To'liq markdown emas, lekin tahlil natijalarini toza ko'rsatadi.
 */
@Composable
fun MarkdownText(md: String, modifier: Modifier = Modifier) {
    val lines = md.replace("\r\n", "\n").split("\n")
    Column(modifier = modifier) {
        lines.forEach { raw ->
            val line = raw.trimEnd()
            when {
                line.isBlank() -> Spacer(Modifier.height(6.dp))

                line.startsWith("### ") -> {
                    Spacer(Modifier.height(4.dp))
                    Text(line.removePrefix("### "), fontSize = 14.sp,
                        fontWeight = FontWeight.Bold, color = Ink)
                }
                line.startsWith("## ") -> {
                    Spacer(Modifier.height(8.dp))
                    Text(line.removePrefix("## "), fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold, color = Feruza)
                    Spacer(Modifier.height(2.dp))
                }
                line.startsWith("# ") -> {
                    Spacer(Modifier.height(8.dp))
                    Text(line.removePrefix("# "), fontSize = 17.sp,
                        fontWeight = FontWeight.Bold, color = Ink)
                }
                line.startsWith("- ") || line.startsWith("* ") -> {
                    Row(modifier = Modifier.padding(top = 3.dp)) {
                        Text("•", fontSize = 14.sp, color = Muted)
                        Spacer(Modifier.width(8.dp))
                        Text(inlineBold(line.substring(2)), fontSize = 14.sp,
                            color = Ink, lineHeight = 20.sp)
                    }
                }
                // "1. " kabi raqamli ro'yxat
                Regex("^\\d+\\. ").containsMatchIn(line) -> {
                    val idx = line.indexOf(". ")
                    Row(modifier = Modifier.padding(top = 3.dp)) {
                        Text(line.substring(0, idx + 1), fontSize = 14.sp,
                            color = Feruza, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.width(6.dp))
                        Text(inlineBold(line.substring(idx + 2)), fontSize = 14.sp,
                            color = Ink, lineHeight = 20.sp)
                    }
                }
                else -> Text(inlineBold(line), fontSize = 14.sp, color = Ink, lineHeight = 20.sp)
            }
        }
    }
}
