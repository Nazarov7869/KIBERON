package uz.ipakyoli.app.ui.map

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.ui.components.ErrorBox
import uz.ipakyoli.app.ui.components.PrimaryButton
import uz.ipakyoli.app.ui.components.SectionCard
import uz.ipakyoli.app.ui.theme.Bad
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.Faint
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Line
import uz.ipakyoli.app.ui.theme.Muted
import uz.ipakyoli.app.ui.theme.Ok
import uz.ipakyoli.app.ui.theme.Surface
import uz.ipakyoli.app.ui.theme.Zafaron

private val LEGEND = listOf(
    Triple("me", Color(0xFF1363DF), "Siz"),
    Triple("warehouse", Color(0xFF1E9E61), "Ombor"),
    Triple("logistics", Color(0xFFC77F1E), "Logistika"),
    Triple("market", Color(0xFFD14B3C), "Bozor"),
    Triple("seller", Color(0xFF0E8F8C), "Sotuvchi"),
    Triple("buyer", Color(0xFF6E5AA6), "Xaridor"),
)

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(vm: MapViewModel = hiltViewModel()) {
    val payload by vm.payload.collectAsState()
    var webRef by remember { mutableStateOf<WebView?>(null) }
    var ready by remember { mutableStateOf(false) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    // Karta yukini WebView'ga uzatish
    androidx.compose.runtime.LaunchedEffect(payload, ready) {
        if (ready) webRef?.evaluateJavascript("window.renderB64('$payload')", null)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Karta", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
            )
        },
        containerColor = Bg,
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 16.dp),
        ) {
            Box(modifier = Modifier.heightIn(max = 330.dp)) {
                if (vm.editing) EditControls(vm) else ExploreControls(vm)
            }

            vm.error?.let {
                Spacer(Modifier.height(8.dp)); ErrorBox(it)
            }

            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, Line, RoundedCornerShape(14.dp)),
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.setSupportZoom(true)
                            settings.builtInZoomControls = false
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    ready = true
                                }
                            }
                            addJavascriptInterface(object {
                                @JavascriptInterface
                                fun onPick(lat: Double, lng: Double) {
                                    mainHandler.post { vm.onPick(lat, lng) }
                                }
                            }, "AndroidBridge")
                            loadUrl("file:///android_asset/leaflet_map.html")
                            webRef = this
                        }
                    },
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun EditControls(vm: MapViewModel) {
    Spacer(Modifier.height(6.dp))
    SectionCard {
        Text("Manzilingizni belgilang", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            "Davom etish uchun joylashuvingizni tanlang — kartani bosing yoki markerni suring.",
            fontSize = 13.sp, color = Muted,
        )
        Spacer(Modifier.height(10.dp))
        val has = vm.draftLat != null && vm.draftLng != null
        if (has) {
            Text("Tanlangan: ${vm.draftLat}, ${vm.draftLng}", fontSize = 12.sp, color = Faint)
            Spacer(Modifier.height(8.dp))
        }
        PrimaryButton(
            text = "Manzilni saqlash",
            onClick = vm::save,
            enabled = has && !vm.saving,
            loading = vm.saving,
        )
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun ExploreControls(vm: MapViewModel) {
    val scroll = rememberScrollState()
    Column(modifier = Modifier.verticalScroll(scroll)) {
        Spacer(Modifier.height(6.dp))
        SectionCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Yo‘nalish taklifi", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
                Text(
                    "Manzilni o‘zgartirish",
                    fontSize = 12.sp, color = Feruza, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { vm.startEditing() },
                )
            }
            Spacer(Modifier.height(10.dp))

            val prodOptions = listOf("" to "Mahsulot (ixtiyoriy)") +
                vm.products.map { it.id to it.name }
            Dropdown(
                options = prodOptions,
                selected = vm.selProduct,
                onSelect = vm::setProduct,
            )
            Spacer(Modifier.height(8.dp))
            val mktOptions = listOf("" to "Manzil bozorini tanlang") +
                (vm.features?.markets?.mapNotNull { m -> m.id?.let { it to m.country } } ?: emptyList())
            Dropdown(
                options = mktOptions,
                selected = vm.selMarket,
                onSelect = vm::setMarket,
            )
            Spacer(Modifier.height(10.dp))
            PrimaryButton(text = "Taklif olish", onClick = vm::getSuggestions)

            vm.sugg?.let { s ->
                Spacer(Modifier.height(12.dp))
                s.market?.let { m ->
                    val km = s.summary?.totalKm
                    val days = s.summary?.transitDays
                    Text(
                        buildString {
                            append(m.country).append(" yo‘nalishi")
                            if (km != null) append(" · ~${fmtD(km)} km")
                            if (days != null) append(" · ~$days kun")
                            if (m.tariffPct != null) append(" · tarif ${fmtD(m.tariffPct)}%")
                        },
                        fontSize = 13.sp, color = Ink, fontWeight = FontWeight.SemiBold,
                    )
                }
                if (s.nearestWarehouses.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("ENG YAQIN OMBORLAR", fontSize = 11.sp, color = Faint, fontWeight = FontWeight.Bold)
                    s.nearestWarehouses.forEach { w ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 3.dp)) {
                            Text("${w.code} · ${w.name}", fontSize = 12.5.sp, color = Ink,
                                modifier = Modifier.weight(1f))
                            w.distKm?.let { Text("${fmtD(it)} km", fontSize = 12.sp, color = Muted) }
                            Spacer(Modifier.size(6.dp))
                            Pill(if (w.suitable == false) "mos emas" else "mos",
                                if (w.suitable == false) Zafaron else Ok)
                        }
                    }
                }
                s.corridor?.let { c ->
                    Spacer(Modifier.height(8.dp))
                    Text("KORIDOR & LOGISTIKA", fontSize = 11.sp, color = Faint, fontWeight = FontWeight.Bold)
                    Text("${c.name}${c.transitDays?.let { " · $it kun" } ?: ""}",
                        fontSize = 12.5.sp, color = Ink, modifier = Modifier.padding(top = 2.dp))
                    if (s.logistics.isNotEmpty()) {
                        s.logistics.forEach { l ->
                            Text("${l.code} · ${l.name}  (${l.modes.joinToString(", ")}${if (l.coldChain) ", sovuq" else ""})",
                                fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 2.dp))
                        }
                    } else {
                        Text("Bu koridorga firma biriktirilmagan", fontSize = 12.sp, color = Faint,
                            modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        // Legend
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Surface)
                .border(1.dp, Line, RoundedCornerShape(14.dp))
                .padding(12.dp),
        ) {
            androidx.compose.foundation.layout.FlowRow(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                LEGEND.forEach { (_, color, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(color))
                        Spacer(Modifier.size(6.dp))
                        Text(label, fontSize = 12.sp, color = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun Dropdown(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val current = options.firstOrNull { it.first == selected }?.second
        ?: options.firstOrNull()?.second.orEmpty()
    Box {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, Line, RoundedCornerShape(10.dp))
                .background(Surface)
                .clickable { open = true }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(current, fontSize = 14.sp, color = if (selected.isBlank()) Muted else Ink)
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Muted)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (value, label) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { onSelect(value); open = false })
            }
        }
    }
}

@Composable
private fun Pill(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    ) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun fmtD(d: Double): String = if (d == d.toLong().toDouble()) d.toLong().toString() else d.toString()
