package uz.ipakyoli.app.ui.market

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import uz.ipakyoli.app.core.network.ApiClient
import uz.ipakyoli.app.core.network.Candle
import uz.ipakyoli.app.core.network.Ticker
import javax.inject.Inject

@HiltViewModel
class MarketViewModel @Inject constructor(
    private val api: ApiClient,
) : ViewModel() {

    var items by mutableStateOf<List<Ticker>>(emptyList()); private set
    var selected by mutableStateOf<Ticker?>(null); private set
    var candles by mutableStateOf<List<Candle>>(emptyList()); private set
    var loading by mutableStateOf(true); private set
    var loadingCandles by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    init { load() }

    fun load() {
        viewModelScope.launch {
            loading = true; error = null
            runCatching { api.marketSummary() }
                .onSuccess {
                    items = it.items
                    if (selected == null) it.items.firstOrNull()?.let { t -> select(t) }
                }
                .onFailure { error = it.message }
            loading = false
        }
    }

    fun select(t: Ticker) {
        selected = t
        viewModelScope.launch {
            loadingCandles = true; candles = emptyList()
            runCatching { api.marketCandles(t.productId, 120) }
                .onSuccess { candles = it.candles }
                .onFailure { error = it.message }
            loadingCandles = false
        }
    }
}
