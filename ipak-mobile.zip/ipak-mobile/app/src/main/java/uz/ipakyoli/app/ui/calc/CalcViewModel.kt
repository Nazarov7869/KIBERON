package uz.ipakyoli.app.ui.calc

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import uz.ipakyoli.app.core.pricing.CalcInput
import uz.ipakyoli.app.core.pricing.CalcResult
import uz.ipakyoli.app.core.pricing.PriceCalculator
import javax.inject.Inject

@HiltViewModel
class CalcViewModel @Inject constructor() : ViewModel() {

    var currency by mutableStateOf("USD")     // "USD" | "UZS"

    // Asosiy
    var cost by mutableStateOf("")
    var qty by mutableStateOf("")
    var margin by mutableStateOf("25")

    // Qo'shimcha xarajatlar
    var packaging by mutableStateOf("")
    var cert by mutableStateOf("")
    var inland by mutableStateOf("")
    var waste by mutableStateOf("")

    // Eksport (konteyner)
    var contCost by mutableStateOf("")
    var contCap by mutableStateOf("20000")
    var insurance by mutableStateOf("0.5")
    var commission by mutableStateOf("2")

    private fun d(s: String, def: Double = 0.0): Double =
        s.replace(',', '.').trim().toDoubleOrNull() ?: def

    val symbol: String get() = if (currency == "USD") "$" else "so'm"
    val prefixSymbol: Boolean get() = currency == "USD"

    val result: CalcResult?
        get() = PriceCalculator.compute(
            CalcInput(
                costPerKg = d(cost),
                quantityKg = d(qty),
                packagingPerKg = d(packaging),
                certificationTotal = d(cert),
                inlandPerKg = d(inland),
                wastePercent = d(waste),
                marginPercent = d(margin, 20.0),
                containerCost = d(contCost),
                containerCapacityKg = d(contCap),
                insurancePercent = d(insurance),
                commissionPercent = d(commission),
            )
        )
}
