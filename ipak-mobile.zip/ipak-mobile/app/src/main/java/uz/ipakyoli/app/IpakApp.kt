package uz.ipakyoli.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Ipak Yo'li ilovasining asosiy Application klassi.
 * Hilt DI shu yerdan boshlanadi.
 */
@HiltAndroidApp
class IpakApp : Application()
