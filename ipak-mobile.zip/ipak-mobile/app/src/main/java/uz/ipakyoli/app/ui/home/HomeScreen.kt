package uz.ipakyoli.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.core.network.Roles
import uz.ipakyoli.app.ui.components.ErrorBox
import uz.ipakyoli.app.ui.components.InfoBanner
import uz.ipakyoli.app.ui.components.LoadingBox
import uz.ipakyoli.app.ui.components.RolePill
import uz.ipakyoli.app.ui.components.StatGrid
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Muted
import uz.ipakyoli.app.ui.theme.Surface
import uz.ipakyoli.app.ui.theme.roleColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpenCalc: () -> Unit = {}, vm: HomeViewModel = hiltViewModel()) {
    val user by vm.user.collectAsState(initial = null)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ipak Yo'li", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = vm::logout) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Chiqish")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
            )
        },
        containerColor = Bg,
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            val name = user?.name?.trim()?.split(" ")?.firstOrNull() ?: ""
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            ) {
                Column {
                    Text("Assalomu alaykum,", fontSize = 14.sp, color = Muted)
                    Text(
                        if (name.isNotEmpty()) name else "Xush kelibsiz",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Ink,
                    )
                }
                user?.let { RolePill(Roles.label(it.role), roleColor(it.role)) }
            }

            Spacer(Modifier.height(14.dp))
            user?.let {
                InfoBanner(text = Roles.hint(it.role), bold = "Nima qilishingiz mumkin:")
            }

            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Feruza)
                    .clickable { onOpenCalc() }
                    .padding(16.dp),
            ) {
                Column {
                    Text("Narx kalkulyatori", color = Surface, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        "Mahsulotingizni qanchaga sotish — hisoblang  →",
                        color = Surface.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Platforma katalogi", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Spacer(Modifier.height(10.dp))

            when {
                vm.loading -> LoadingBox()
                vm.error != null -> ErrorBox(vm.error!!)
                vm.summary != null -> {
                    val s = vm.summary!!
                    StatGrid(
                        items = listOf(
                            s.products.toString() to "Mahsulot",
                            s.markets.toString() to "Bozor",
                            s.corridors.toString() to "Koridor",
                            s.warehouses.toString() to "Ombor",
                            s.providers.toString() to "Logistika",
                            s.certifications.toString() to "Sertifikat",
                        ),
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
