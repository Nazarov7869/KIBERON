package uz.ipakyoli.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private val DISC = Color(0xFF23282F)
private val GOLD_L = Color(0xFFF7DB86)
private val GOLD_M = Color(0xFFE0AF48)
private val GOLD_D = Color(0xFFB87E1C)

/**
 * SILK ROAD kompas belgisi — qorong'u disk ichida oltin, qirrali (pinwheel)
 * to'rt burchakli kompas yulduzi. Canvas orqali chiziladi.
 */
@Composable
fun BrandMark(size: Int = 40) {
    Canvas(modifier = Modifier.size(size.dp)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        val rDisc = s * 0.47f

        // disk + oltin halqa
        drawCircle(color = DISC, radius = rDisc, center = c)
        drawCircle(color = GOLD_M, radius = rDisc - s * 0.02f, center = c, style = Stroke(width = s * 0.045f))

        val inner = s * 0.10f

        // qirrali nur: har yo'nalish uchun ikki uchburchak (qorong'u/yorug' oltin)
        fun ray(deg: Double, len: Float, dark: Color, light: Color) {
            val a = Math.toRadians(deg)
            val aL = Math.toRadians(deg - 45.0)
            val aR = Math.toRadians(deg + 45.0)
            val tx = c.x + (len * sin(a)).toFloat()
            val ty = c.y - (len * cos(a)).toFloat()
            val blx = c.x + (inner * sin(aL)).toFloat()
            val bly = c.y - (inner * cos(aL)).toFloat()
            val brx = c.x + (inner * sin(aR)).toFloat()
            val bry = c.y - (inner * cos(aR)).toFloat()
            val left = Path().apply { moveTo(c.x, c.y); lineTo(tx, ty); lineTo(blx, bly); close() }
            val right = Path().apply { moveTo(c.x, c.y); lineTo(tx, ty); lineTo(brx, bry); close() }
            drawPath(left, dark)
            drawPath(right, light)
        }

        // 4 asosiy nur (uzun)
        listOf(0.0, 90.0, 180.0, 270.0).forEach { ray(it, s * 0.35f, GOLD_D, GOLD_L) }
        // 4 diagonal nur (kalta)
        listOf(45.0, 135.0, 225.0, 315.0).forEach {
            ray(it, s * 0.19f, GOLD_D.copy(alpha = 0.85f), GOLD_L.copy(alpha = 0.9f))
        }

        // markaziy teshik
        drawCircle(color = DISC, radius = s * 0.055f, center = c)
        drawCircle(color = GOLD_M, radius = s * 0.055f, center = c, style = Stroke(width = s * 0.015f))
    }
}

/** SILK ROAD so'z-logo (kompas + matn). */
@Composable
fun BrandWordmark(markSize: Int = 34) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        BrandMark(size = markSize)
        Spacer(Modifier.width(10.dp))
        Row {
            Text("SILK", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF23282F))
            Text("ROAD", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GOLD_D)
        }
    }
}
