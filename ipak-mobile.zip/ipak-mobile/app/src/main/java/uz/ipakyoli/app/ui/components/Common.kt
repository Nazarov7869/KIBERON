package uz.ipakyoli.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.ipakyoli.app.ui.theme.Bad
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Feruza050
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Line
import uz.ipakyoli.app.ui.theme.Muted
import uz.ipakyoli.app.ui.theme.Surface
import uz.ipakyoli.app.ui.theme.Zafaron

@Composable
fun SectionCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Surface),
        border = BorderStroke(1.dp, Line),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp)) { content() }
    }
}

@Composable
fun InfoBanner(text: String, bold: String? = null) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Feruza050)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Column {
            if (bold != null) {
                Text(bold, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 14.sp)
            }
            Text(text, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun RolePill(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color)
            .padding(horizontal = 12.dp, vertical = 5.dp),
    ) {
        Text(label, color = Surface, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun StatCard(value: String, label: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val base = Modifier
        .clip(RoundedCornerShape(14.dp))
        .background(Surface)
    Column(
        modifier = (if (onClick != null) base.clickable { onClick() } else base)
            .then(modifier)
            .padding(horizontal = 14.dp, vertical = 16.dp),
    ) {
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Feruza)
        Text(label, fontSize = 12.sp, color = Muted)
    }
}

@Composable
fun LoadingBox() {
    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Feruza)
    }
}

@Composable
fun ErrorBox(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF9E7E4))
            .padding(14.dp),
    ) {
        Text(message, color = Bad, fontSize = 13.sp)
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    loading: Boolean = false,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (enabled && !loading) Feruza else Feruza.copy(alpha = 0.5f))
            .clickable(enabled = enabled && !loading) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        if (loading) {
            CircularProgressIndicator(color = Surface, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
        } else {
            Text(text, color = Surface, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        }
    }
}

/** Kichik statistika to'ri qatori (2 ustun). */
@Composable
fun StatGrid(items: List<Pair<String, String>>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(2).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                row.forEach { (value, label) ->
                    StatCard(value = value, label = label, modifier = Modifier.weight(1f))
                }
                if (row.size == 1) Box(modifier = Modifier.weight(1f))
            }
        }
    }
}
