package uz.ipakyoli.app.ui.auth

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.ui.components.BrandMark
import uz.ipakyoli.app.ui.components.ErrorBox
import uz.ipakyoli.app.ui.components.PrimaryButton
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Muted

@Composable
fun LoginScreen(onOpenCalc: () -> Unit = {}, vm: LoginViewModel = hiltViewModel()) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        BrandMark(size = 56)
        Spacer(Modifier.height(16.dp))
        Text("Ipak Yo'li", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Milliy agroeksport platformasi", fontSize = 13.sp, color = Muted)
        Spacer(Modifier.height(28.dp))

        OutlinedTextField(
            value = vm.email,
            onValueChange = vm::onEmail,
            label = { Text("Email") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = vm.password,
            onValueChange = vm::onPassword,
            label = { Text("Parol") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            modifier = Modifier.fillMaxWidth(),
        )

        if (vm.error != null) {
            Spacer(Modifier.height(12.dp))
            ErrorBox(vm.error!!)
        }

        Spacer(Modifier.height(20.dp))
        PrimaryButton(
            text = "Kirish",
            onClick = vm::login,
            loading = vm.loading,
            enabled = vm.email.isNotBlank() && vm.password.isNotBlank(),
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Operator: admin@ipakyoli.uz",
            fontSize = 12.sp,
            color = Muted,
        )
        Spacer(Modifier.height(28.dp))
        Text(
            "Narx kalkulyatori  →",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = Feruza,
            modifier = Modifier.clickable { onOpenCalc() },
        )
        Text(
            "Login shart emas — mahsulot narxini hisoblang",
            fontSize = 12.sp,
            color = Muted,
        )
    }
}
