package uz.ipakyoli.app.ui.nav

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import uz.ipakyoli.app.core.network.User
import uz.ipakyoli.app.data.AuthRepository
import javax.inject.Inject

sealed interface AuthUi {
    data object Loading : AuthUi
    data object LoggedOut : AuthUi
    data class LoggedIn(val user: User) : AuthUi
}

@HiltViewModel
class AuthGateViewModel @Inject constructor(
    auth: AuthRepository,
) : ViewModel() {
    val state: StateFlow<AuthUi> = auth.currentUser
        .map { if (it == null) AuthUi.LoggedOut else AuthUi.LoggedIn(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AuthUi.Loading)
}
