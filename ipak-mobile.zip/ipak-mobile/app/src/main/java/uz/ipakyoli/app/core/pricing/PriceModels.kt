package uz.ipakyoli.app.core.pricing

// =====================================================================
//  Narx kalkulyatori — kirish va natija modellari (sof Kotlin, offline)
// =====================================================================

/** Tadbirkor kiritadigan xarajatlar. Barcha pul qiymatlari bir valyutada. */
data class CalcInput(
    val costPerKg: Double,                 // tannarx / xarid narxi (1 kg)
    val quantityKg: Double,                // miqdor (kg)
    val packagingPerKg: Double = 0.0,      // qadoqlash (1 kg)
    val certificationTotal: Double = 0.0,  // sertifikat/hujjat (jami)
    val inlandPerKg: Double = 0.0,         // mahalliy transport portgacha (1 kg)
    val wastePercent: Double = 0.0,        // yo'qotish/brak (%)
    val marginPercent: Double = 20.0,      // foyda (%)
    // Eksport (ixtiyoriy — bo'sh qoldirilsa faqat mahalliy narx hisoblanadi)
    val containerCost: Double = 0.0,       // to'liq konteyner xalqaro yuk narxi
    val containerCapacityKg: Double = 0.0, // to'liq konteyner sig'imi (kg)
    val insurancePercent: Double = 0.0,    // sug'urta (CFR ustidan, %)
    val commissionPercent: Double = 0.0,   // platforma komissiyasi (%)
)

/** Hisob natijasi — barcha qiymatlar 1 kg uchun (total_ bilan boshlanganlar — jami). */
data class CalcResult(
    val certPerKg: Double,
    val breakEvenPerKg: Double,     // zararsizlik (foydasiz tannarx, EXW)
    val exwPricePerKg: Double,      // tavsiya narx (foyda bilan), zavod/xo'jalikda
    val profitPerKg: Double,
    val fobPricePerKg: Double,      // + mahalliy transport (portda, yuklangan)
    val cfrPooledPerKg: Double,     // + xalqaro yuk (konteyner bo'lishilgan)
    val cifPooledPerKg: Double,     // + sug'urta
    val cifSoloPerKg: Double,       // yakka jo'natgandagi CIF (taqqoslash uchun)
    val freightSoloPerKg: Double,
    val freightPooledPerKg: Double,
    val commissionPerKg: Double,
    val poolingSavingPerKg: Double, // konteynerni bo'lishishdan tejam (1 kg)
    val poolingSavingPercent: Double,
    val totalCost: Double,          // umumiy tannarx (butun partiya)
    val totalProfit: Double,
    val totalCifPooled: Double,
    val totalPoolingSaving: Double,
    val hasExport: Boolean,         // eksport bosqichlari kiritilganmi
)
