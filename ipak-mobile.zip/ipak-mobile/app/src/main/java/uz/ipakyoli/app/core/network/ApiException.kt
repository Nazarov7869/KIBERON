package uz.ipakyoli.app.core.network

/** Backend qaytargan xatolik (HTTP status + xabar). */
class ApiException(val status: Int, message: String) : Exception(message)
