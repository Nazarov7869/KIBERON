package uz.ipakyoli.app.ui.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.ui.components.MarkdownText
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.Faint
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Feruza050
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Line
import uz.ipakyoli.app.ui.theme.Muted
import uz.ipakyoli.app.ui.theme.Surface
import uz.ipakyoli.app.ui.theme.Warn

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiChatScreen(vm: AiChatViewModel = hiltViewModel()) {
    val listState = rememberLazyListState()

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI maslahatchi", fontWeight = FontWeight.Bold)
                        vm.status?.let {
                            Text(
                                if (it.configured) "Faol · ${it.provider ?: ""}" else "Sozlanmagan",
                                fontSize = 11.sp,
                                color = if (it.configured) Feruza else Warn,
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
            )
        },
        containerColor = Bg,
    ) { pad ->
        Column(modifier = Modifier.fillMaxSize().padding(pad)) {
            if (vm.status?.configured == false) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Warn.copy(alpha = 0.12f))
                        .padding(12.dp),
                ) {
                    Text(
                        "AI hali sozlanmagan. Administrator sozlamalarda AI provayder kalitini kiritishi kerak.",
                        fontSize = 12.5.sp, color = Warn,
                    )
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (vm.messages.isEmpty()) {
                    EmptyState(vm)
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        item { Spacer(Modifier.height(8.dp)) }
                        items(vm.messages) { m -> MessageBubble(m) }
                        if (vm.sending) {
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(
                                        color = Feruza, strokeWidth = 2.dp,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(Modifier.size(8.dp))
                                    Text("O‘ylayapman…", fontSize = 13.sp, color = Muted)
                                }
                            }
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                    }
                }
            }

            InputBar(
                value = vm.input,
                onValue = vm::onInput,
                onSend = vm::send,
                enabled = !vm.sending,
            )
        }
    }
}

@Composable
private fun EmptyState(vm: AiChatViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Eksport bo‘yicha savol bering", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            "AI maslahatchi bozor, koridor, narx va hujjatlar bo‘yicha yordam beradi.",
            fontSize = 13.sp, color = Muted,
        )
        Spacer(Modifier.height(16.dp))
        vm.suggestions.forEach { s ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Surface)
                    .border(1.dp, Line, RoundedCornerShape(12.dp))
                    .clickable { vm.sendText(s) }
                    .padding(14.dp),
            ) {
                Text(s, fontSize = 13.5.sp, color = Ink)
            }
        }
    }
}

@Composable
private fun MessageBubble(m: ChatMsg) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start,
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (m.fromUser) Feruza else Surface)
                .then(
                    if (m.fromUser) Modifier
                    else Modifier.border(1.dp, Line, RoundedCornerShape(16.dp)),
                )
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            if (m.fromUser) {
                Text(m.text, color = Surface, fontSize = 14.sp)
            } else {
                MarkdownText(m.text)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InputBar(value: String, onValue: (String) -> Unit, onSend: () -> Unit, enabled: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Bg)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValue,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Savol yozing…", color = Faint) },
            shape = RoundedCornerShape(24.dp),
            maxLines = 4,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Surface,
                unfocusedContainerColor = Surface,
                focusedIndicatorColor = Feruza,
                unfocusedIndicatorColor = Line,
            ),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
        )
        Spacer(Modifier.size(8.dp))
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(if (enabled && value.isNotBlank()) Feruza else Feruza050)
                .clickable(enabled = enabled && value.isNotBlank()) { onSend() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.AutoMirrored.Filled.Send,
                contentDescription = "Yuborish",
                tint = if (enabled && value.isNotBlank()) Surface else Feruza,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}
