package uz.ipakyoli.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val KoshinLightScheme = lightColorScheme(
    primary = Feruza,
    onPrimary = Surface,
    primaryContainer = Feruza050,
    onPrimaryContainer = Feruza700,

    secondary = Lojuvard,
    onSecondary = Surface,
    secondaryContainer = Lojuvard050,
    onSecondaryContainer = Lojuvard700,

    tertiary = Zafaron,
    onTertiary = Surface,
    tertiaryContainer = Zafaron050,

    error = Bad,
    onError = Surface,

    background = Bg,
    onBackground = Ink,

    surface = Surface,
    onSurface = Ink,
    surfaceVariant = Surface2,
    onSurfaceVariant = Muted,

    outline = LineStrong,
    outlineVariant = Line,
)

@Composable
fun IpakTheme(
    // Ilova bir xil ko'rinishi uchun doim och tema
    darkTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = KoshinLightScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Bg.toArgb()
            window.navigationBarColor = Bg.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = true   // och fonda qora ikonkalar
            controller.isAppearanceLightNavigationBars = true
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = IpakTypography,
        content = content,
    )
}
