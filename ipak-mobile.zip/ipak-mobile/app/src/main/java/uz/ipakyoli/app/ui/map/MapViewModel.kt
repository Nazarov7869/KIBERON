package uz.ipakyoli.app.ui.map

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import uz.ipakyoli.app.core.network.ApiClient
import uz.ipakyoli.app.core.network.MapFeatures
import uz.ipakyoli.app.core.network.MapMarker
import uz.ipakyoli.app.core.network.MapPayload
import uz.ipakyoli.app.core.network.MyLoc
import uz.ipakyoli.app.core.network.Product
import uz.ipakyoli.app.core.network.Suggestions
import javax.inject.Inject

@HiltViewModel
class MapViewModel @Inject constructor(
    private val api: ApiClient,
    private val json: Json,
) : ViewModel() {

    var me by mutableStateOf<MyLoc?>(null); private set
    var features by mutableStateOf<MapFeatures?>(null); private set
    var products by mutableStateOf<List<Product>>(emptyList()); private set
    var sugg by mutableStateOf<Suggestions?>(null); private set

    var draftLat by mutableStateOf<Double?>(null); private set
    var draftLng by mutableStateOf<Double?>(null); private set
    var editing by mutableStateOf(false); private set

    var selProduct by mutableStateOf(""); private set
    var selMarket by mutableStateOf(""); private set

    var loading by mutableStateOf(true); private set
    var saving by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    // WebView'ga uzatiladigan yuk (base64 JSON) — o'zgarsa karta yangilanadi
    private val _payload = MutableStateFlow(encode(MapPayload(pick = false, zoom = 6)))
    val payload: StateFlow<String> = _payload.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            loading = true; error = null
            runCatching { api.mapMe() }
                .onSuccess { me = it; editing = !it.isSet }
                .onFailure { error = it.message }
            runCatching { api.products() }.onSuccess { products = it }
            if (me?.isSet == true && !editing) loadFeatures()
            loading = false
            refresh()
        }
    }

    private suspend fun loadFeatures() {
        runCatching { api.mapFeatures() }
            .onSuccess { features = it }
            .onFailure { error = it.message }
    }

    fun onPick(lat: Double, lng: Double) {
        draftLat = lat; draftLng = lng
        refresh()
    }

    fun startEditing() {
        me?.let { draftLat = it.lat; draftLng = it.lng }
        editing = true; sugg = null
        refresh()
    }

    fun save() {
        val la = draftLat; val ln = draftLng
        if (la == null || ln == null) return
        viewModelScope.launch {
            saving = true; error = null
            runCatching { api.mapSetMe(la, ln) }
                .onSuccess {
                    me = it; editing = false; draftLat = null; draftLng = null
                    loadFeatures()
                }
                .onFailure { error = it.message }
            saving = false
            refresh()
        }
    }

    fun setProduct(v: String) { selProduct = v }
    fun setMarket(v: String) { selMarket = v }

    fun getSuggestions() {
        if (selMarket.isBlank()) { error = "Manzil bozorini tanlang"; return }
        viewModelScope.launch {
            error = null
            runCatching { api.mapSuggestions(selMarket, selProduct.ifBlank { null }) }
                .onSuccess { sugg = it }
                .onFailure { error = it.message }
            refresh()
        }
    }

    fun clearSuggestions() { sugg = null; refresh() }

    // ---- Karta yukini yig'ish ----
    private fun buildPayload(): MapPayload {
        if (editing) {
            val meArr = if (draftLat != null && draftLng != null) listOf(draftLat!!, draftLng!!) else null
            return MapPayload(me = meArr, pick = true, zoom = if (meArr != null) 11 else 6)
        }
        val f = features
        val markers = mutableListOf<MapMarker>()
        f?.warehouses?.forEach {
            if (it.lat != null && it.lng != null) markers.add(
                MapMarker(it.lat, it.lng, "warehouse",
                    html = "<b>${esc(it.code)} · ${esc(it.name)}</b><br>${esc(it.region)}" +
                        (it.capacity?.let { c -> "<br>Bo‘sh: ${fmt(c)} t" } ?: "") +
                        (it.distKm?.let { d -> "<br><b>${fmt(d)} km</b>" } ?: ""))
            )
        }
        f?.logistics?.forEach {
            if (it.lat != null && it.lng != null) markers.add(
                MapMarker(it.lat, it.lng, "logistics",
                    html = "<b>${esc(it.code)} · ${esc(it.name)}</b>" +
                        (it.hubCity?.let { h -> "<br>Hub: ${esc(h)}" } ?: "") +
                        (if (it.modes.isNotEmpty()) "<br>${it.modes.joinToString(", ")}" else ""))
            )
        }
        f?.markets?.forEach {
            if (it.lat != null && it.lng != null) markers.add(
                MapMarker(it.lat, it.lng, "market",
                    html = "<b>${esc(it.country)}</b>" +
                        (it.corridorName?.let { c -> "<br>${esc(c)}" } ?: "") +
                        (it.transitDays?.let { d -> " · $d kun" } ?: "") +
                        (it.tariffPct?.let { t -> "<br>Tarif: ${fmt(t)}%" } ?: ""))
            )
        }
        f?.partners?.forEach {
            if (it.lat != null && it.lng != null) markers.add(
                MapMarker(it.lat, it.lng, it.type,
                    html = "<b>${esc(it.name)}</b>" +
                        (it.region?.let { r -> "<br>${esc(r)}" } ?: "") +
                        (it.distKm?.let { d -> "<br>${fmt(d)} km" } ?: ""))
            )
        }
        val meArr = me?.let { if (it.lat != null && it.lng != null) listOf(it.lat, it.lng) else null }
        return MapPayload(me = meArr, markers = markers, route = sugg?.route, pick = false,
            zoom = if (me?.role == "importer") 4 else 6)
    }

    private fun refresh() { _payload.value = encode(buildPayload()) }

    private fun encode(p: MapPayload): String {
        val s = json.encodeToString(MapPayload.serializer(), p)
        return android.util.Base64.encodeToString(s.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
    }

    private fun esc(s: String?): String = (s ?: "").replace("<", "&lt;").replace("'", "’")
    private fun fmt(d: Double): String = if (d == d.toLong().toDouble()) d.toLong().toString() else d.toString()
}
