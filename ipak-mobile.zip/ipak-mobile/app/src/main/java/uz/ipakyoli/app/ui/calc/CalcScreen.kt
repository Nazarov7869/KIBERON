package uz.ipakyoli.app.ui.calc

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.core.pricing.CalcResult
import uz.ipakyoli.app.ui.components.InfoBanner
import uz.ipakyoli.app.ui.components.SectionCard
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Feruza050
import uz.ipakyoli.app.ui.theme.Feruza700
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Line
import uz.ipakyoli.app.ui.theme.Muted
import uz.ipakyoli.app.ui.theme.Ok
import uz.ipakyoli.app.ui.theme.Surface
import uz.ipakyoli.app.ui.theme.Zafaron050

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalcScreen(onBack: () -> Unit, vm: CalcViewModel = hiltViewModel()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Narx kalkulyatori", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Orqaga")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
            )
        },
        containerColor = Bg,
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            InfoBanner(
                bold = "Mahsulotingizni qanchaga sotish kerak?",
                text = "Xarajatlaringizni kiriting — zararsizlik narxi, tavsiya sotuv narxi va eksport bosqichlarini hisoblaymiz.",
            )

            // Valyuta tanlagichi
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CurrencyPill("USD", vm.currency == "USD") { vm.currency = "USD" }
                CurrencyPill("So'm", vm.currency == "UZS") { vm.currency = "UZS" }
            }

            val sym = vm.symbol

            // ---- Asosiy ----
            SectionCard {
                SectionHeader("Asosiy")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumField("Tannarx (1 kg)", vm.cost, { vm.cost = it }, Modifier.weight(1f), sym)
                    NumField("Miqdor", vm.qty, { vm.qty = it }, Modifier.weight(1f), "kg")
                }
                Spacer(Modifier.height(10.dp))
                NumField("Foyda", vm.margin, { vm.margin = it }, suffix = "%")
            }

            // ---- Qo'shimcha xarajatlar ----
            SectionCard {
                SectionHeader("Qo'shimcha xarajatlar (ixtiyoriy)")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumField("Qadoqlash (1 kg)", vm.packaging, { vm.packaging = it }, Modifier.weight(1f), sym)
                    NumField("Yo'qotish/brak", vm.waste, { vm.waste = it }, Modifier.weight(1f), "%")
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumField("Sertifikat (jami)", vm.cert, { vm.cert = it }, Modifier.weight(1f), sym)
                    NumField("Mahalliy trans. (1 kg)", vm.inland, { vm.inland = it }, Modifier.weight(1f), sym)
                }
            }

            // ---- Eksport (konteyner) ----
            SectionCard {
                SectionHeader("Eksport — konteyner (ixtiyoriy)")
                Text(
                    "To'ldirsangiz eksport narxi (FOB/CFR/CIF) va konteyner to'ldirish foydasi hisoblanadi.",
                    fontSize = 12.sp, color = Muted,
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumField("Konteyner yuk narxi", vm.contCost, { vm.contCost = it }, Modifier.weight(1f), sym)
                    NumField("Konteyner sig'imi", vm.contCap, { vm.contCap = it }, Modifier.weight(1f), "kg")
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumField("Sug'urta", vm.insurance, { vm.insurance = it }, Modifier.weight(1f), "%")
                    NumField("Platforma komis.", vm.commission, { vm.commission = it }, Modifier.weight(1f), "%")
                }
            }

            // ---- NATIJA ----
            val r = vm.result
            if (r == null) {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface)
                        .border(1.dp, Line, RoundedCornerShape(14.dp)).padding(20.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Natijani ko'rish uchun tannarx va miqdorni kiriting", color = Muted, fontSize = 13.sp)
                }
            } else {
                ResultBlock(r, sym, vm.prefixSymbol)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ---------------------------------------------------------------------
//  Natija bloki
// ---------------------------------------------------------------------
@Composable
private fun ResultBlock(r: CalcResult, sym: String, prefix: Boolean) {
    fun p(v: Double) = price(v, sym, prefix, 2)
    fun t(v: Double) = price(v, sym, prefix, 0)

    // Ikki bosh karta: zararsizlik + tavsiya narx
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        HeadlineCard("Zararsizlik", p(r.breakEvenPerKg), "1 kg · bundan past = zarar", Zafaron050, Ink, Modifier.weight(1f))
        HeadlineCard("Tavsiya narx", p(r.exwPricePerKg), "1 kg · foyda ${p(r.profitPerKg)}", Feruza050, Feruza700, Modifier.weight(1f))
    }

    if (r.hasExport) {
        Spacer(Modifier.height(12.dp))
        SectionCard {
            SectionHeader("Eksport narx bosqichlari (1 kg)")
            Spacer(Modifier.height(6.dp))
            LadderRow("EXW — xo'jalikda", p(r.exwPricePerKg))
            LadderRow("FOB — portda", p(r.fobPricePerKg))
            LadderRow("CFR — + xalqaro yuk", p(r.cfrPooledPerKg))
            LadderRow("CIF — + sug'urta", p(r.cifPooledPerKg), strong = true)
            if (r.commissionPerKg > 0) {
                Spacer(Modifier.height(4.dp))
                Text("Platforma komissiyasi: ${p(r.commissionPerKg)}/kg", fontSize = 12.sp, color = Muted)
            }
        }

        if (r.poolingSavingPerKg > 0) {
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Feruza).padding(16.dp),
            ) {
                Column {
                    Text("Konteyner to'ldirish foydasi", color = Surface, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    SaveRow("Yakka jo'natish (to'lmaydi)", p(r.cifSoloPerKg))
                    SaveRow("Ipak Yo'li konteynerida", p(r.cifPooledPerKg))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Tejam: ${p(r.poolingSavingPerKg)}/kg  ·  ${"%.1f".format(r.poolingSavingPercent)}%  ·  jami ${t(r.totalPoolingSaving)}",
                        color = Surface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    )
                }
            }
        }
    }

    // Umumiy (butun partiya)
    Spacer(Modifier.height(12.dp))
    SectionCard {
        SectionHeader("Butun partiya")
        Spacer(Modifier.height(6.dp))
        LadderRow("Umumiy tannarx", t(r.totalCost))
        LadderRow("Umumiy foyda", t(r.totalProfit), color = Ok)
        if (r.hasExport) LadderRow("CIF qiymati (eksport)", t(r.totalCifPooled), strong = true)
    }
}

// ---------------------------------------------------------------------
//  Kichik komponentlar + formatlash
// ---------------------------------------------------------------------
@Composable
private fun NumField(
    label: String,
    value: String,
    onValue: (String) -> Unit,
    modifier: Modifier = Modifier,
    suffix: String? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        suffix = suffix?.let { { Text(it) } },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
private fun SectionHeader(text: String) {
    Text(text, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 15.sp)
}

@Composable
private fun CurrencyPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (selected) Feruza else Surface)
            .border(1.dp, if (selected) Feruza else Line, RoundedCornerShape(999.dp))
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 8.dp),
    ) {
        Text(label, color = if (selected) Surface else Muted, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable
private fun HeadlineCard(
    title: String, value: String, sub: String,
    bg: Color, valueColor: Color, modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .padding(14.dp),
    ) {
        Text(title, fontSize = 12.sp, color = Muted, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = valueColor)
        Spacer(Modifier.height(2.dp))
        Text(sub, fontSize = 11.sp, color = Muted)
    }
}

@Composable
private fun LadderRow(label: String, value: String, strong: Boolean = false, color: Color = Ink) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, color = Muted)
        Text(
            value,
            fontSize = if (strong) 15.sp else 13.sp,
            fontWeight = if (strong) FontWeight.Bold else FontWeight.SemiBold,
            color = if (strong) Feruza else color,
        )
    }
}

@Composable
private fun SaveRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, color = Surface.copy(alpha = 0.85f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Surface)
    }
}

private fun price(v: Double, symbol: String, prefix: Boolean, decimals: Int): String {
    val n = if (decimals == 2) "%,.2f".format(v) else "%,.0f".format(v)
    return if (prefix) "$symbol$n" else "$n $symbol"
}
