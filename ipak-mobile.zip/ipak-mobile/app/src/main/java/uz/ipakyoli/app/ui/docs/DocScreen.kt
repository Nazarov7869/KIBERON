package uz.ipakyoli.app.ui.docs

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import uz.ipakyoli.app.ui.components.ErrorBox
import uz.ipakyoli.app.ui.components.MarkdownText
import uz.ipakyoli.app.ui.components.PrimaryButton
import uz.ipakyoli.app.ui.components.SectionCard
import uz.ipakyoli.app.ui.theme.Bg
import uz.ipakyoli.app.ui.theme.Faint
import uz.ipakyoli.app.ui.theme.Feruza
import uz.ipakyoli.app.ui.theme.Feruza050
import uz.ipakyoli.app.ui.theme.Feruza700
import uz.ipakyoli.app.ui.theme.Ink
import uz.ipakyoli.app.ui.theme.Line
import uz.ipakyoli.app.ui.theme.Muted
import uz.ipakyoli.app.ui.theme.Surface

private val DOC_MIME = arrayOf(
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/msword",
    "text/plain",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocScreen(vm: DocViewModel = hiltViewModel()) {
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let { vm.analyzeUri(it) } },
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hujjat tahlili", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
            )
        },
        containerColor = Bg,
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            Spacer(Modifier.height(4.dp))
            Text(
                "Eksport shartnomasi, invoys yoki sertifikatni yuklang — AI mutaxassis " +
                    "band-band tahlil qiladi: shartlar, xavflar, yetishmayotgan bandlar va tavsiyalar.",
                fontSize = 13.sp, color = Muted, lineHeight = 19.sp,
            )
            Spacer(Modifier.height(14.dp))

            if (vm.result == null && !vm.analyzing) {
                // Fayl tanlash
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Feruza050)
                        .border(1.dp, Feruza.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .clickable { picker.launch(DOC_MIME) }
                        .padding(vertical = 22.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = Feruza,
                            modifier = Modifier.size(34.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Fayl tanlash", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Feruza700)
                        Text("PDF · DOCX · TXT (maks. 10 MB)", fontSize = 12.sp, color = Muted)
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).height(1.dp).background(Line))
                    Text("  yoki matnni joylashtiring  ", fontSize = 12.sp, color = Faint)
                    Box(Modifier.weight(1f).height(1.dp).background(Line))
                }
                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = vm.pastedText,
                    onValueChange = vm::onText,
                    modifier = Modifier.fillMaxWidth().height(160.dp),
                    placeholder = { Text("Shartnoma yoki hujjat matnini bu yerga qo‘ying…", color = Faint) },
                    shape = RoundedCornerShape(12.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Surface,
                        unfocusedContainerColor = Surface,
                        focusedIndicatorColor = Feruza,
                        unfocusedIndicatorColor = Line,
                    ),
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    text = "Matnni tahlil qilish",
                    onClick = vm::analyzeText,
                    enabled = vm.pastedText.trim().length >= 20,
                )
            }

            vm.error?.let {
                Spacer(Modifier.height(12.dp)); ErrorBox(it)
                Spacer(Modifier.height(12.dp))
                PrimaryButton(text = "Qayta urinish", onClick = vm::reset)
            }

            if (vm.analyzing) {
                Spacer(Modifier.height(30.dp))
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CircularProgressIndicator(color = Feruza)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        vm.pickedName?.let { "“$it” tahlil qilinmoqda…" } ?: "Tahlil qilinmoqda…",
                        fontSize = 13.sp, color = Muted,
                    )
                }
            }

            vm.result?.let { r ->
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(vm.pickedName ?: "Hujjat tahlili", fontWeight = FontWeight.Bold,
                            fontSize = 15.sp, color = Ink)
                        val meta = buildString {
                            r.provider?.let { append(it) }
                            if (r.truncated) append(" · qisqartirilgan")
                        }
                        if (meta.isNotBlank()) Text(meta, fontSize = 11.sp, color = Faint)
                    }
                    Text("Boshqa hujjat", fontSize = 12.sp, color = Feruza, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { vm.reset() })
                }
                Spacer(Modifier.height(10.dp))
                SectionCard {
                    MarkdownText(r.analysis ?: "—")
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Eslatma: bu tahlil faqat ma'lumot uchun. Muhim shartnomalar bo‘yicha malakali yurist bilan maslahatlashing.",
                    fontSize = 11.sp, color = Faint, lineHeight = 16.sp,
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
