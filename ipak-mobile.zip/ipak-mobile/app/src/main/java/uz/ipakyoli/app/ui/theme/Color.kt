package uz.ipakyoli.app.ui.theme

import androidx.compose.ui.graphics.Color

// =====================================================================
//  KOSHIN — majolika palitrasi (och tema)
// =====================================================================
// Feruza (asosiy)
val Feruza = Color(0xFF0E8F8C)
val Feruza700 = Color(0xFF0B6F6C)
val Feruza050 = Color(0xFFE1F1F0)

// Lojuvard (ikkilamchi)
val Lojuvard = Color(0xFF27508F)
val Lojuvard700 = Color(0xFF1D3D6E)
val Lojuvard050 = Color(0xFFE4EAF3)

// Za'faron (uchlamchi / urg'u)
val Zafaron = Color(0xFFC77F1E)
val Zafaron050 = Color(0xFFF7ECD9)

// Fon va yuzalar
val Bg = Color(0xFFECEEEA)
val Surface = Color(0xFFFFFFFF)
val Surface2 = Color(0xFFF4F5F2)

// Matn
val Ink = Color(0xFF1A1D1A)
val Muted = Color(0xFF5C635C)
val Faint = Color(0xFF8A908A)

// Chegara
val Line = Color(0xFFDCDFD9)
val LineStrong = Color(0xFFC7CBC4)

// Holat ranglari (badge)
val Ok = Color(0xFF2E7D5B)
val Warn = Color(0xFFB4791C)
val Bad = Color(0xFFB2432F)

// Rollar (dashboard tanlagichi)
val RoleAdmin = Lojuvard
val RoleExporter = Feruza
val RoleImporter = Zafaron
val RoleLogistics = Color(0xFF6B7280)
val RoleWarehouse = Color(0xFF7A5C3E)
val RoleEmbassy = Color(0xFF5B7C99)

fun roleColor(role: String): Color = when (role) {
    "super_admin" -> RoleAdmin
    "exporter" -> RoleExporter
    "importer" -> RoleImporter
    "logistics" -> RoleLogistics
    "warehouse" -> RoleWarehouse
    "embassy" -> RoleEmbassy
    else -> Feruza
}
