package uz.ipakyoli.app.core.network

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// =====================================================================
//  Yangi imkoniyatlar uchun data klasslar: Katalog, Birja, Karta, AI
// =====================================================================

// ---------- Katalog ----------
@Serializable
data class Product(
    val id: String,
    val name: String,
    @SerialName("hs_code") val hsCode: String? = null,
    val kind: String? = null,
    @SerialName("storage_class") val storageClass: String? = null,
    @SerialName("avg_price_usd_ton") val avgPrice: Double? = null,
)

@Serializable
data class ProductsResponse(val ok: Boolean = true, val products: List<Product> = emptyList())

// ---------- Birja (bozor tahlili) ----------
@Serializable
data class Ticker(
    @SerialName("product_id") val productId: String,
    val name: String,
    val kind: String? = null,
    val last: Double? = null,
    val prev: Double? = null,
    @SerialName("change_abs") val changeAbs: Double? = null,
    @SerialName("change_pct") val changePct: Double? = null,
    @SerialName("high_30d") val high30d: Double? = null,
    @SerialName("low_30d") val low30d: Double? = null,
    val volume: Double? = null,
    val source: String? = null,
)

@Serializable
data class MarketSummary(
    val ok: Boolean = true,
    val currency: String = "USD",
    val unit: String = "tonna",
    val items: List<Ticker> = emptyList(),
)

@Serializable
data class Candle(val t: String, val o: Double, val h: Double, val l: Double, val c: Double, val v: Double)

@Serializable
data class CandlesResponse(
    val ok: Boolean = true,
    @SerialName("product_id") val productId: String? = null,
    val source: String? = null,
    val candles: List<Candle> = emptyList(),
)

// ---------- Karta ----------
@Serializable
data class MyLoc(
    val ok: Boolean = true,
    val role: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val address: String? = null,
    @SerialName("is_set") val isSet: Boolean = false,
)

@Serializable
data class LocationBody(val lat: Double, val lng: Double, val address: String? = null)

@Serializable
data class WarehousePoint(
    val code: String? = null,
    val name: String,
    val lat: Double? = null,
    val lng: Double? = null,
    val region: String? = null,
    @SerialName("capacity_free_t") val capacity: Double? = null,
    val rate: Double? = null,
    val rating: Double? = null,
    @SerialName("storage_classes") val storageClasses: List<String> = emptyList(),
    @SerialName("dist_km") val distKm: Double? = null,
    val suitable: Boolean? = null,
)

@Serializable
data class LogisticsPoint(
    val code: String? = null,
    val name: String,
    val lat: Double? = null,
    val lng: Double? = null,
    @SerialName("hub_city") val hubCity: String? = null,
    val modes: List<String> = emptyList(),
    @SerialName("cold_chain") val coldChain: Boolean = false,
    val rating: Double? = null,
    @SerialName("dist_km") val distKm: Double? = null,
)

@Serializable
data class MarketPoint(
    val id: String? = null,
    val country: String,
    val city: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    @SerialName("tariff_pct") val tariffPct: Double? = null,
    @SerialName("corridor_name") val corridorName: String? = null,
    @SerialName("transit_days") val transitDays: Int? = null,
)

@Serializable
data class PartnerPoint(
    val type: String,
    val name: String,
    val region: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val verified: Boolean? = null,
    @SerialName("dist_km") val distKm: Double? = null,
)

@Serializable
data class Corridor(
    val name: String,
    val waypoints: List<List<Double>> = emptyList(),
    @SerialName("entry_point") val entryPoint: List<Double>? = null,
    @SerialName("transit_days") val transitDays: Int? = null,
)

@Serializable
data class MapFeatures(
    val ok: Boolean = true,
    val role: String? = null,
    val me: MyLoc? = null,
    val warehouses: List<WarehousePoint> = emptyList(),
    val logistics: List<LogisticsPoint> = emptyList(),
    val markets: List<MarketPoint> = emptyList(),
    val partners: List<PartnerPoint> = emptyList(),
    val corridors: List<Corridor> = emptyList(),
)

@Serializable
data class ProductBrief(
    val id: String? = null,
    val name: String? = null,
    @SerialName("storage_class") val storageClass: String? = null,
)

@Serializable
data class RouteSummary(
    @SerialName("leg_to_warehouse_km") val legKm: Double? = null,
    @SerialName("warehouse_to_border_km") val borderKm: Double? = null,
    @SerialName("corridor_km") val corridorKm: Double? = null,
    @SerialName("total_km") val totalKm: Double? = null,
    @SerialName("transit_days") val transitDays: Int? = null,
)

@Serializable
data class Suggestions(
    val ok: Boolean = true,
    val product: ProductBrief? = null,
    @SerialName("nearest_warehouses") val nearestWarehouses: List<WarehousePoint> = emptyList(),
    val market: MarketPoint? = null,
    val corridor: Corridor? = null,
    val logistics: List<LogisticsPoint> = emptyList(),
    val route: List<List<Double>>? = null,
    val summary: RouteSummary? = null,
)

// Karta WebView (Leaflet) uchun yuk
@Serializable
data class MapMarker(
    val lat: Double,
    val lng: Double,
    val type: String,
    val label: String = "",
    val html: String = "",
)

@Serializable
data class MapPayload(
    val me: List<Double>? = null,
    val markers: List<MapMarker> = emptyList(),
    val route: List<List<Double>>? = null,
    val pick: Boolean = false,
    val zoom: Int = 6,
)

// ---------- AI ----------
@Serializable
data class AiStatus(
    val ok: Boolean = true,
    val provider: String? = null,
    val configured: Boolean = false,
    val source: String? = null,
)

@Serializable
data class AdvisorBody(val question: String, val preview: Boolean = false)

@Serializable
data class AdvisorResponse(
    val ok: Boolean = true,
    val answer: String? = null,
    val provider: String? = null,
    val model: String? = null,
)

@Serializable
data class AnalyzeBody(val text: String, val kind: String? = null)

@Serializable
data class AnalyzeResponse(
    val ok: Boolean = true,
    val analysis: String? = null,
    val provider: String? = null,
    val model: String? = null,
    val truncated: Boolean = false,
    val filename: String? = null,
    val chars: Int? = null,
)
