package uz.ipakyoli.app.core.pricing

import kotlin.math.max

// =====================================================================
//  Narx hisoblash — sof funksiya (tannarx + foyda -> eksport Incoterm)
//  Formula shaffof; backend/mobil/web bir xil natija berishi uchun.
// =====================================================================
object PriceCalculator {

    /**
     * @return CalcResult, yoki null — agar tannarx yoki miqdor noto'g'ri bo'lsa.
     */
    fun compute(input: CalcInput): CalcResult? {
        if (input.costPerKg <= 0.0 || input.quantityKg <= 0.0) return null

        val qty = input.quantityKg

        // Yo'qotish/brakni hisobga olgan samarali tannarx
        val lossFactor = (1.0 - input.wastePercent / 100.0).coerceIn(0.01, 1.0)
        val effectiveCost = input.costPerKg / lossFactor

        val certPerKg = if (qty > 0) input.certificationTotal / qty else 0.0

        // EXW tannarx (xo'jalikda tayyor mahsulot) = zararsizlik
        val breakEven = effectiveCost + input.packagingPerKg + certPerKg
        val exwPrice = breakEven * (1.0 + input.marginPercent / 100.0)
        val profit = exwPrice - breakEven

        // FOB = + mahalliy transport (port/chegaragacha, yuklangan)
        val fob = exwPrice + input.inlandPerKg

        val hasExport = input.containerCost > 0.0 && input.containerCapacityKg > 0.0

        // Xalqaro yuk (1 kg): yakka (konteyner to'lmaydi) va bo'lishilgan (to'liq konteyner)
        val freightSolo = if (hasExport && qty > 0) input.containerCost / qty else 0.0
        val freightPooled = if (hasExport) input.containerCost / input.containerCapacityKg else 0.0

        val cfrPooled = fob + freightPooled
        val cfrSolo = fob + freightSolo

        val cifPooled = cfrPooled * (1.0 + input.insurancePercent / 100.0)
        val cifSolo = cfrSolo * (1.0 + input.insurancePercent / 100.0)

        val commission = cifPooled * input.commissionPercent / 100.0

        val savingPerKg = max(0.0, cifSolo - cifPooled)
        val savingPercent = if (cifSolo > 0.0) savingPerKg / cifSolo * 100.0 else 0.0

        return CalcResult(
            certPerKg = certPerKg,
            breakEvenPerKg = breakEven,
            exwPricePerKg = exwPrice,
            profitPerKg = profit,
            fobPricePerKg = fob,
            cfrPooledPerKg = cfrPooled,
            cifPooledPerKg = cifPooled,
            cifSoloPerKg = cifSolo,
            freightSoloPerKg = freightSolo,
            freightPooledPerKg = freightPooled,
            commissionPerKg = commission,
            poolingSavingPerKg = savingPerKg,
            poolingSavingPercent = savingPercent,
            totalCost = breakEven * qty,
            totalProfit = profit * qty,
            totalCifPooled = cifPooled * qty,
            totalPoolingSaving = savingPerKg * qty,
            hasExport = hasExport,
        )
    }
}
