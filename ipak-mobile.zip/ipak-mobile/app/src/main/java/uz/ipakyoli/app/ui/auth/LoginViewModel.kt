package uz.ipakyoli.app.ui.auth

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import uz.ipakyoli.app.data.AuthRepository
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val auth: AuthRepository,
) : ViewModel() {

    var email by mutableStateOf("")
        private set
    var password by mutableStateOf("")
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun onEmail(v: String) { email = v; error = null }
    fun onPassword(v: String) { password = v; error = null }

    fun login() {
        if (email.isBlank() || password.isBlank()) {
            error = "Email va parolni kiriting"
            return
        }
        viewModelScope.launch {
            loading = true
            error = null
            val res = auth.login(email, password)
            loading = false
            res.onFailure { error = it.message ?: "Kirishda xatolik" }
            // Muvaffaqiyatli bo'lsa currentUser oqimi yangilanadi -> nav avtomatik o'tadi
        }
    }
}
