package uz.ipakyoli.app.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import uz.ipakyoli.app.core.network.ApiClient
import uz.ipakyoli.app.core.network.Summary
import uz.ipakyoli.app.core.network.User
import uz.ipakyoli.app.data.AuthRepository
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val api: ApiClient,
    private val auth: AuthRepository,
) : ViewModel() {

    val user: Flow<User?> = auth.currentUser

    var summary by mutableStateOf<Summary?>(null)
        private set
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    init { load() }

    fun load() {
        viewModelScope.launch {
            loading = true
            error = null
            runCatching { api.catalogSummary() }
                .onSuccess { summary = it }
                .onFailure { error = it.message ?: "Ma'lumotni yuklab bo'lmadi" }
            loading = false
        }
    }

    fun logout() {
        viewModelScope.launch { auth.logout() }
    }
}
