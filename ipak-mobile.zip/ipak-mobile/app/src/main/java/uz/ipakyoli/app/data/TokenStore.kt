package uz.ipakyoli.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "ipak_prefs")

// =====================================================================
//  JWT token + foydalanuvchi (JSON) ni qurilmada saqlash (DataStore)
// =====================================================================
@Singleton
class TokenStore @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val ds = context.dataStore

    val tokenFlow: Flow<String?> = ds.data.map { it[KEY_TOKEN] }
    val userJsonFlow: Flow<String?> = ds.data.map { it[KEY_USER] }

    suspend fun save(token: String, userJson: String) {
        ds.edit {
            it[KEY_TOKEN] = token
            it[KEY_USER] = userJson
        }
    }

    suspend fun clear() {
        ds.edit { it.clear() }
    }

    private companion object {
        val KEY_TOKEN = stringPreferencesKey("token")
        val KEY_USER = stringPreferencesKey("user")
    }
}
