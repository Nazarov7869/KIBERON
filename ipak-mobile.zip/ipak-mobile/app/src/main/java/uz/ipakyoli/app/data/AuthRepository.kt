package uz.ipakyoli.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import uz.ipakyoli.app.core.network.ApiClient
import uz.ipakyoli.app.core.network.User
import javax.inject.Inject
import javax.inject.Singleton

// =====================================================================
//  Auth holati — kirish/chiqish + joriy foydalanuvchi (reaktiv oqim)
// =====================================================================
@Singleton
class AuthRepository @Inject constructor(
    private val api: ApiClient,
    private val tokenStore: TokenStore,
    private val json: Json,
) {
    /** Saqlangan foydalanuvchi (token bilan). null = kirilmagan. */
    val currentUser: Flow<User?> = tokenStore.userJsonFlow.map { raw ->
        raw?.let { s -> runCatching { json.decodeFromString(User.serializer(), s) }.getOrNull() }
    }

    suspend fun login(email: String, password: String): Result<User> = runCatching {
        val resp = api.login(email.trim(), password)
        val userJson = json.encodeToString(User.serializer(), resp.user)
        tokenStore.save(resp.accessToken, userJson)
        resp.user
    }

    suspend fun logout() {
        tokenStore.clear()
    }
}
