import java.io.FileInputStream
import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.hilt)
    alias(libs.plugins.ksp)
}

// ─────────────────────────────────────────────────────────────
// RELEASE SIGNING — keystore.properties mavjud bo'lsa undan o'qiladi
// (Git'ga qo'shilmaydi). Bo'lmasa debug imzo ishlatiladi, build buzilmaydi.
// ─────────────────────────────────────────────────────────────
val keystorePropertiesFile = rootProject.file("keystore.properties")

android {
    namespace = "uz.ipakyoli.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "uz.ipakyoli.app"
        minSdk = 26                 // Android 8.0+ (adaptive icon uchun)
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }

        // 🌐 BACKEND — standart (release) manzil. Debug'da 10.0.2.2 ga o'zgaradi.
        // Release API — DOMEN orqali (IP emas). Domeningizga moslang.
        buildConfigField("String", "API_BASE_URL", "\"https://ipakapi.elektronbozor.uz\"")
    }

    val releaseSigning = if (keystorePropertiesFile.exists()) {
        val props = Properties()
        FileInputStream(keystorePropertiesFile).use { props.load(it) }
        signingConfigs.create("release") {
            storeFile = file(props.getProperty("storeFile"))
            storePassword = props.getProperty("storePassword")
            keyAlias = props.getProperty("keyAlias")
            keyPassword = props.getProperty("keyPassword")
        }
    } else null

    buildTypes {
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            // API — DOMEN orqali (release bilan bir xil). Emulatorda lokal backend kerak bo'lsa
            // bu qatorni "http://10.0.2.2:4000" ga o'zgartiring (debug cleartext ruxsat berilgan).
            buildConfigField("String", "API_BASE_URL", "\"https://ipakapi.elektronbozor.uz\"")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = releaseSigning ?: signingConfigs.getByName("debug")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = true
        warningsAsErrors = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    // Core Android
    implementation(libs.core.ktx)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.lifecycle.viewmodel.compose)

    // Compose
    implementation(libs.activity.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons.extended)
    implementation(libs.navigation.compose)

    // Hilt (Dependency Injection)
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    // Networking
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)
    implementation(libs.kotlinx.serialization.json)

    // Async
    implementation(libs.kotlinx.coroutines.android)

    // Storage (JWT token + user)
    implementation(libs.datastore.preferences)

    // Testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.compose.ui.test.junit4)
    debugImplementation(libs.compose.ui.tooling)
    debugImplementation(libs.compose.ui.test.manifest)
}
