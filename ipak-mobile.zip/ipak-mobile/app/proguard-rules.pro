# Ipak Yo'li - ProGuard/R8 qoidalari

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class **$$serializer { *; }
-keepclasseswithmembers class * {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class uz.ipakyoli.app.**$$serializer { *; }
-keepclassmembers class uz.ipakyoli.app.core.network.** {
    *** Companion;
    kotlinx.serialization.KSerializer serializer(...);
}

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Data model klasslari (@Serializable)
-keep @kotlinx.serialization.Serializable class uz.ipakyoli.app.core.network.** { *; }
